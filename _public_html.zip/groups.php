<?php
declare(strict_types=1);
require_once __DIR__ . "/auth_guard.php";
?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Groups</title></head>
<body>
  <h2>Groups</h2>
  <p>Coming soon.</p>
  <p><a href="/dashboard.php">Back to dashboard</a></p>
</body>
</html>
